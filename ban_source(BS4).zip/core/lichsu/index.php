
<div class="row">
<!-- panel 2 -->
<div class="col-lg-4" style="visibility: visible; animation-duration: 1s; animation-name:fadeIn;">
   <div class="card">
      <div class="card-header text-center">Lịch Sử Mua Token</div>
         <div class="card-body">
            <!-- STAR-->
             <div class="table-responsive">
              <table id="lich_su_mua_token" class="table table-bordered dataTable" role="grid" aria-describedby="default-datatable_info">
               <thead>
                 <tr>
                     <th>Thời Gian</th>
                     <th>Số Lượng</th>
                     <th>Mua bởi</th>
                     <th>TÙY CHỌN</th>
                  </tr>
                  <tbody>
                     
                     <?php
                        if($username == $admin){ 
                           $SQL_muahang = mysqli_query($kunloc,"SELECT * FROM lich_su_mua WHERE username='$username' AND count_token > 0");
                        }else{
                           $SQL_muahang = mysqli_query($kunloc,"SELECT * FROM lich_su_mua WHERE count_token > 0");
                        }
                        while($kunloc_muahang = mysqli_fetch_assoc($SQL_muahang)){ ?>
                        <tr>
                            <td><?= date("H:i:s d/m/Y",$kunloc_muahang['time']); ?></td>
                            <td><?= $kunloc_muahang['count_token']; ?></td>
                            <td><?= $kunloc_muahang['username']; ?></td>
                            <td> <a href="/log/lichsu/lichsutoken.php?time=<?= $kunloc_muahang['time']; ?>"style="color:red">Click xem</a></td>
                         </tr>
                     <?php } ?>
                  </tbody>
            </table>
         </div>
         
      </div>
<!-- end -->
</div>
</div>
<!-- panel 2 -->
<div class="col-lg-4" style="visibility: visible; animation-duration: 1s; animation-name:fadeIn;">
   <div class="card">
      <div class="card-header text-center">Lịch Sử Mua Mail</div>
         <div class="card-body">
            <!-- STAR-->
             <div class="table-responsive">
              <table id="lich_su_mua_mail" class="table table-bordered dataTable" role="grid" aria-describedby="default-datatable_info">
               <thead>
                 <tr>
                     <th>Thời Gian</th>
                     <th>Số Lượng</th>
                     <th>Mua bởi</th>
                     <th>TÙY CHỌN</th>
                  </tr>
                  <tbody>
                     <?php
                     if($username == $admin){ 
                        $SQL_muahang = mysqli_query($kunloc,"SELECT * FROM lich_su_mua_mail WHERE username='$username' AND count_mail > 0");
                     }else{
                        $SQL_muahang = mysqli_query($kunloc,"SELECT * FROM lich_su_mua_mail");
                     }
                        while($kunloc_muahang = mysqli_fetch_assoc($SQL_muahang)){ ?>
                        <tr>
                            <td><?= date("H:i:s d/m/Y",$kunloc_muahang['time']); ?></td>
                            <td><?= $kunloc_muahang['count_mail']; ?></td>
                            <td><?= $kunloc_muahang['username']; ?></td>
                            <td> <a href="/log/lichsu/lichsumail.php?time=<?= $kunloc_muahang['time']; ?>"style="color:red">Click xem</a></td>
                         </tr>
                     <?php } ?>
                  </tbody>
            </table>
         </div>
         
      </div>
<!-- end -->
</div>
</div>
<!-- panel 2 -->
<div class="col-lg-4" style="visibility: visible; animation-duration: 1s; animation-name:fadeIn;">
   <div class="card">
      <div class="card-header text-center">Lịch Sử Mua Clone</div>
         <div class="card-body">
            <!-- STAR-->
             <div class="table-responsive">
              <table id="lich_su_mua_clone" class="table table-bordered dataTable" role="grid" aria-describedby="default-datatable_info">
               <thead>
                 <tr>
                     <th>Thời Gian</th>
                     <th>Số Lượng</th>
                     <th>Mua bởi</th>
                     <th>TÙY CHỌN</th>
                  </tr>
                  <tbody>
                  <?php
                        if($username == $admin){ 
                           $SQL_muahang = mysqli_query($kunloc,"SELECT * FROM lich_su_mua_clone WHERE username='$username' AND count_token > 0");
                        }else{
                           $SQL_muahang = mysqli_query($kunloc,"SELECT * FROM lich_su_mua_clone WHERE count_clone > 0");
                        }
                        while($kunloc_muahang = mysqli_fetch_assoc($SQL_muahang)){ ?>
                        <tr>
                            <td><?= date("H:i:s d/m/Y",$kunloc_muahang['time']); ?></td>
                            <td><?= $kunloc_muahang['count_clone']; ?></td>
                            <td><?= $kunloc_muahang['username']; ?></td>
                            <td> <a href="/log/lichsu/lichsuclone.php?time=<?= $kunloc_muahang['time']; ?>"style="color:red">Click xem</a></td>
                         </tr>
                     <?php } ?>
                  </tbody>
            </table>
         </div>
         
      </div>
<!-- end -->
</div>
</div>
<!-- row -->   
</div>   
<script>
 $(document).ready(function() {
    var table = $('#lich_su_nap_the').DataTable( {
    lengthChange: true,
      "aaSorting": [
                [0, "desc"]
            ],
        "iDisplayLength": 3,
        "aLengthMenu": [
            [3, 10, 20, 30, 40, 50, 100, 200, 500, 1000, -1],
            [3, 10, 20, 30, 40, 50, 100, 200, 500, 1000, "Tất cả"]
        ],
        "oLanguage": {
            "lengthMenu": "Hiển thị _MENU_ mục",
            "zeroRecords": "Không tìm thấy kết quả",
            "sInfo": "Hiển Thị _START_ trong _END_ của _TOTAL_ mục",
            "sEmptyTable": "Không có dữ liệu trong bảng",
            "sInfoEmpty": "Hiển Thị 0 trong 0 của 0 bảng",
            "sInfoFiltered": "(Đã lọc từ _MAX_ tổng bảng)",
            "sInfoPostFix": "",
            "sDecimal": "",
            "sThousands": ",",
            "sLengthMenu": "Hiển thị _MENU_ mục",
            "sLoadingRecords": "Đang tải...",
            "sProcessing": "Processing...",
            "sSearch": "Tiềm kiếm:",
            "sZeroRecords": "Không tìm thấy kết quả",
            "sSearchPlaceholder": "Nhập từ cần tìm...",
            "oPaginate": {
                "sFirst": "ĐẦU",
                "sLast": "Cuối",
                "sNext": "Tiếp",
                "sPrevious": "Trước"
            },
            "oAria": {
                "sSortAscending": ": ASC Tăng Dần",
                "sSortDescending": ": DESC Giảm Dần"
            }
        }
  })
  var table = $('#lich_su_mua_token').DataTable( {
    lengthChange: true,
      "aaSorting": [
                [0, "desc"]
            ],
        "iDisplayLength": 6,
        "aLengthMenu": [
            [6, 10, 20, 30, 40, 50, 100, 200, 500, 1000, -1],
            [6, 10, 20, 30, 40, 50, 100, 200, 500, 1000, "Tất cả"]
        ],
        "oLanguage": {
            "lengthMenu": "Hiển thị _MENU_ mục",
            "zeroRecords": "Không tìm thấy kết quả",
            "sInfo": "Hiển Thị _START_ trong _END_ của _TOTAL_ mục",
            "sEmptyTable": "Không có dữ liệu trong bảng",
            "sInfoEmpty": "Hiển Thị 0 trong 0 của 0 bảng",
            "sInfoFiltered": "(Đã lọc từ _MAX_ tổng bảng)",
            "sInfoPostFix": "",
            "sDecimal": "",
            "sThousands": ",",
            "sLengthMenu": "Hiển thị _MENU_ mục",
            "sLoadingRecords": "Đang tải...",
            "sProcessing": "Processing...",
            "sSearch": "Tiềm kiếm:",
            "sZeroRecords": "Không tìm thấy kết quả",
            "sSearchPlaceholder": "Nhập từ cần tìm...",
            "oPaginate": {
                "sFirst": "ĐẦU",
                "sLast": "Cuối",
                "sNext": "Tiếp",
                "sPrevious": "Trước"
            },
            "oAria": {
                "sSortAscending": ": ASC Tăng Dần",
                "sSortDescending": ": DESC Giảm Dần"
            }
        }
  })
  var table = $('#lich_su_mua_mail').DataTable( {
    lengthChange: true,
      "aaSorting": [
                [0, "desc"]
            ],
        "iDisplayLength": 6,
        "aLengthMenu": [
            [6, 10, 20, 30, 40, 50, 100, 200, 500, 1000, -1],
            [6, 10, 20, 30, 40, 50, 100, 200, 500, 1000, "Tất cả"]
        ],
        "oLanguage": {
            "lengthMenu": "Hiển thị _MENU_ mục",
            "zeroRecords": "Không tìm thấy kết quả",
            "sInfo": "Hiển Thị _START_ trong _END_ của _TOTAL_ mục",
            "sEmptyTable": "Không có dữ liệu trong bảng",
            "sInfoEmpty": "Hiển Thị 0 trong 0 của 0 bảng",
            "sInfoFiltered": "(Đã lọc từ _MAX_ tổng bảng)",
            "sInfoPostFix": "",
            "sDecimal": "",
            "sThousands": ",",
            "sLengthMenu": "Hiển thị _MENU_ mục",
            "sLoadingRecords": "Đang tải...",
            "sProcessing": "Processing...",
            "sSearch": "Tiềm kiếm:",
            "sZeroRecords": "Không tìm thấy kết quả",
            "sSearchPlaceholder": "Nhập từ cần tìm...",
            "oPaginate": {
                "sFirst": "ĐẦU",
                "sLast": "Cuối",
                "sNext": "Tiếp",
                "sPrevious": "Trước"
            },
            "oAria": {
                "sSortAscending": ": ASC Tăng Dần",
                "sSortDescending": ": DESC Giảm Dần"
            }
        }
  })
  var table = $('#lich_su_mua_clone').DataTable( {
    lengthChange: true,
      "aaSorting": [
                [0, "desc"]
            ],
        "iDisplayLength": 6,
        "aLengthMenu": [
            [6, 10, 20, 30, 40, 50, 100, 200, 500, 1000, -1],
            [6, 10, 20, 30, 40, 50, 100, 200, 500, 1000, "Tất cả"]
        ],
        "oLanguage": {
            "lengthMenu": "Hiển thị _MENU_ mục",
            "zeroRecords": "Không tìm thấy kết quả",
            "sInfo": "Hiển Thị _START_ trong _END_ của _TOTAL_ mục",
            "sEmptyTable": "Không có dữ liệu trong bảng",
            "sInfoEmpty": "Hiển Thị 0 trong 0 của 0 bảng",
            "sInfoFiltered": "(Đã lọc từ _MAX_ tổng bảng)",
            "sInfoPostFix": "",
            "sDecimal": "",
            "sThousands": ",",
            "sLengthMenu": "Hiển thị _MENU_ mục",
            "sLoadingRecords": "Đang tải...",
            "sProcessing": "Processing...",
            "sSearch": "Tiềm kiếm:",
            "sZeroRecords": "Không tìm thấy kết quả",
            "sSearchPlaceholder": "Nhập từ cần tìm...",
            "oPaginate": {
                "sFirst": "ĐẦU",
                "sLast": "Cuối",
                "sNext": "Tiếp",
                "sPrevious": "Trước"
            },
            "oAria": {
                "sSortAscending": ": ASC Tăng Dần",
                "sSortDescending": ": DESC Giảm Dần"
            }
        }
  })
   table.buttons().container() .appendTo( '#example_wrapper .col-md-6:eq(0)' );
})

function done(id) {
		 $.get('API/api_admin.php', { duyet_the: id }, function(data, status) {
              var Data = JSON.parse(data)
                if(Data.success){
                    Swal.fire("Duyệt Thẻ!","Đã duyệt","success");
                    setTimeout(() => { window.location.href = 'Lichsu'; },1000);
                }
         })
}
function xoa(id) {
		 $.get('API/api_admin.php', { tu_choi_the: id }, function(data, status) {
              var Data = JSON.parse(data)
                if(Data.success){
                    Swal.fire("Từ Chối Thẻ!","Đã từ chối","success");
                    setTimeout(() => { window.location.href = 'Lichsu'; },1000);
                }
         })
}
</script>