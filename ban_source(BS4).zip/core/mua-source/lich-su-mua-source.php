 <!-- ADS -->
 <?= $ads_2x ?>
<?= $ads_auto ?>
<!-- /./ -->
<div class="row">
<!-- bounceIn -->
<div class="col-lg-12 features-box">
    <div class="card">
      <div class="card-header">Danh Sách Source Đã Mua</div>
         <div class="card-body">
         <div class="table-responsive">
         <table id="danh-sach" class="table table-striped table-bordered nowrap scroll-horizontal-vertical">
               <thead>
                  <tr>
                     <th>Tùy Chọn</th>
                     <th>Thumbable</th>
                     <th>Thông tin Source</th>
                     <th>Giá Source</th>
                     <th>Dowload Code</th>
                     <th>NGƯỜI MUA</th
                  </tr>
                <tbody>
                <?php
                     if($username == $admin){
                         $SQL = mysqli_query($kunloc,"SELECT * FROM lich_su_mua_code ORDER BY id DESC");
                     }else{
                         $SQL = mysqli_query($kunloc,"SELECT * FROM lich_su_mua_code WHERE username = '$username' ORDER BY id DESC");
                     }
                     while ($kunloc = mysqli_fetch_assoc($SQL)):?>
                  <tr>
                    <td>
                        <div class="media">
                            <div class="avatar">
                                <img class="align-self-start" src="<?= $kunloc['image']; ?>" href="<?= $kunloc['image']; ?>" data-fancybox="" style="margin-left:-10px;width:150px;height:auto" alt="user avatar">
                            </div>
                        </div>
					           </td>
                     <td>
                         <span href="#" onclick="remove(<?= $kunloc['id']; ?>)" class="btn-sm btn-danger" data-toggle="tooltip" title="Nhấp vào để xóa">Gỡ lịch sử MUA</span>
                     </td>
                     <td>
                      Mã code:<b data-toggle="tooltip" title="Mã CODE" style="color:blue"><code><?= $kunloc['code']; ?></code></b><br>
                      Ngày mua: <b data-toggle="tooltip" title="Ngày tạo" style="color:black"><?= $kunloc['date']; ?></b><br>
                      Tiêu đề: <b data-toggle="tooltip" title="Tiều đề" style="color:blue"><?= $kunloc['title']; ?></b><br> 
                     </td>
                     <td>
                      <b data-toggle="tooltip" title="Giá source" style="color:red">
                      <?php if($kunloc['gia'] != 0){
                        echo number_format($kunloc['gia']);
                      }else{
                        echo 'Miễn phí';
                      }
                      ?>
                      </b> VND
                     </td>
                     <td>
                       <b data-toggle="tooltip" title="Download" style="color:black">
                       <a href="<?= $kunloc['download']; ?>"target="_blank">Click để tải CODE</a></b></td>
                     <td><b data-toggle="tooltip" title="Người mua" style="color:green"><?= $kunloc['username']; ?></b></td>
                  
                  </tr>
                  <?php $i++; endwhile; ?>
                  </tbody>
               </thead>
            </table>
            </div>

     </div>
</div>


</div>
<!-- ADS -->
<?= $ads_2x ?>  
<?= $ads_auto ?>   
<!-- end row ADS /./ -->
<script type="text/javascript">
$(document).ready(function() {
    var table = $('#danh-sach').DataTable( {
    lengthChange: true,
    "aaSorting": [
            [0, "desc"]
        ],
        "iDisplayLength": 5,
        "aLengthMenu": [
            [5, 10, 20, 30, 40, 50, 100, 200, 500, 1000, -1],
            [5, 10, 20, 30, 40, 50, 100, 200, 500, 1000, "Tất cả"]
        ],
        "oLanguage": {
            "lengthMenu": "Hiển thị _MENU_ mục",
            "zeroRecords": "Không tìm thấy kết quả",
            "sInfo": "Hiển Thị _START_ trong _END_ của _TOTAL_ mục",
            "sEmptyTable": "Không có dữ liệu trong bảng",
            "sInfoEmpty": "Hiển Thị 0 trong 0 của 0 bảng",
            "sInfoFiltered": "(Đã lọc từ _MAX_ tổng bảng)",
            "sInfoPostFix": "",
            "sDecimal": "",
            "sThousands": ",",
            "sLengthMenu": "Hiển thị _MENU_ mục",
            "sLoadingRecords": "Đang tải...",
            "sProcessing": "Processing...",
            "sSearch": "Tiềm kiếm:",
            "sZeroRecords": "Không tìm thấy kết quả",
            "sSearchPlaceholder": "Nhập từ cần tìm...",
            "oPaginate": {
                "sFirst": "ĐẦU",
                "sLast": "Cuối",
                "sNext": "Tiếp",
                "sPrevious": "Trước"
            },
            "oAria": {
                "sSortAscending": ": ASC Tăng Dần", 
                "sSortDescending": ": DESC Giảm Dần"
            }
        }
  });
   table.buttons().container().appendTo( '#example_wrapper .col-md-6:eq(0)' );
})

function remove(id) {
 		const swalWithBootstrapButtons = Swal.mixin({
  customClass: {
    confirmButton: 'm-1 btn-sm btn-success',
    cancelButton: 'm-1 btn-sm btn-danger'
  },
  buttonsStyling: true
})
swalWithBootstrapButtons.fire({
  title: 'Xác nhận xóa lịch sử này?',
  text: "Bạn chắc chắn muốn xóa!",
  icon: 'info',
  showCancelButton: true,
  confirmButtonText: 'Đồng ý',
  cancelButtonText: 'Hoàn tác',
  reverseButtons: false
}).then((result) => {
  if (result.value) {
    $.post('core/mua-source/setting.php', { 
           type: 'remove', 
           id: id
        }, function(data) {
            Data = JSON.parse(data);
            if(Data.reload){
                setTimeout(() => { location.reload() }, Data.time)
            }
            Swal.fire(Data.title, Data.text,Data.type)
            return false;
    })
  } 
})
return false;
}
</script>