<?php
	session_start();
    require_once("../../config.php");
    if(empty($username)){
        $JSON = array(
            "title" => "Bạn chưa đăng nhập",
            "text" => "Xin đăng nhập để mua source",
            "type" => "error",
            #"reload" => "dang-nhap-he-thong",
            #"time" => $time_swal
        );
        die(json_encode($JSON, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    }
	if(empty($_POST['code'])){
        $JSON = array(
            "title" => "Yêu cầu thông tin",
            "text" => "Bạn chưa điền đầy đủ thông tin",
            "type" => "info",
        );
        die(json_encode($JSON, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    }
    $code = intval($_POST['code']);
    if(mysqli_num_rows(mysqli_query($kunloc,"SELECT * FROM blog WHERE code = '$code'"))){
        $SQL = mysqli_fetch_object(mysqli_query($kunloc,"SELECT * FROM blog WHERE code = '$code'"));
        $gia_source = str_replace('.', '', $SQL->gia); 
        if($vnd < $SQL->gia){
            $JSON = array(
                "title" => "Số dư hiện tại không đủ",
                "text" => "Bạn vui lòng nạp thêm rồi thử lại",
                "type" => "error",
            );
            die(json_encode($JSON, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
     }
     $kiemtra = mysqli_num_rows(mysqli_query($kunloc,"SELECT * FROM lich_su_mua_code WHERE code = '$code' AND username = '$username'"));
     if($kiemtra >= 1){
        $JSON = array(
            "title" => "Bạn đã mua source này rồi",
            "text" => "Vui lòng kiểm tra lại lịch sử",
            "type" => "error",
        );
        die(json_encode($JSON, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
     }
     $thanhtoan = mysqli_query($kunloc,"INSERT INTO lich_su_mua_code(username,code,image,title,gia, date, download) VALUES ('$username','".$SQL->code."','".$SQL->image."','".$SQL->title."','$gia_source','$today','".$SQL->download."')");
     if($thanhtoan){
            mysqli_query($kunloc,"UPDATE account SET VND = VND-$gia_source WHERE username = '$username' ");
            mysqli_query($kunloc,"UPDATE blog SET pay = pay+1 WHERE code = '$code' ");
            if(mysqli_num_rows(mysqli_query($kunloc,"SELECT id FROM log_vnd WHERE username = '$username' "))){
                mysqli_query($kunloc,"UPDATE log_vnd SET VND = VND + $gia_source,date = '$today' WHERE username = '$username'");
            }else{
                mysqli_query($kunloc,"INSERT INTO log_vnd(username,VND,date) VALUES('$username','$gia_source','$today')");
            }
            $JSON = array(
                "title" => "Thanh toán thành công",
                "text" => "Cảm ơn bạn đã ủng hộ chúng tôi!",
                "type" => "success",
                #"reload" => "lich-su-mua-source",
                #"time" => $time_swal
            );
            die(json_encode($JSON, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
        }else{
            $JSON = array(
                "title" => "Thanh toán bất bại",
                "text" => "Xin hãy thử lại hoặc quay lại sau!",
                "type" => "error",
            );
            die(json_encode($JSON, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
        }
    }
?>