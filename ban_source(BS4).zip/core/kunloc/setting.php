<?php
    session_start();
    require_once("../../config.php");
    if(isset($_REQUEST['type'])){
        $Case = $_REQUEST['type'];
        switch($Case){
          case 'img':
            $background = isset($_POST['background']) ? $_POST['background'] : '';
            $logo = isset($_POST['logo']) ? $_POST['logo'] : '';
            $image1 = isset($_POST['image1']) ? $_POST['image1'] : '';
            $image2 = isset($_POST['image2']) ? $_POST['image2'] : '';
            $image3 = isset($_POST['image3']) ? $_POST['image3'] : '';
            $image4 = isset($_POST['image4']) ? $_POST['image4'] : '';
            if(empty($background) || empty($logo) || empty($image1) || empty($image2) || empty($image3) || empty($image4)){
                $JSON = array(
                    "title" => "Yêu cầu thông tin",
                    "text" => "Bạn chưa điền đầy đủ thông tin",
                    "type" => "info",
                );
                die(json_encode($JSON, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
            }
            if(mysqli_num_rows(mysqli_query($kunloc,"SELECT id FROM setting")) == 1){
                mysqli_query($kunloc,
                "UPDATE setting SET id=1,
                    image1='$image1',
                    image2='$image2',
                    image3='$image3',
                    image4='$image4',
                    background='$background',
                    logo='$logo' WHERE 1");
                    $JSON = array(
                        "title" => "Lưu ảnh thành công",
                        "text" => "Chờ reload",
                        "type" => "success",
                        "reload" => "true",
                        "time" => $time_swal
                    );
                    die(json_encode($JSON, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
            }else{
                mysqli_query($kunloc,"INSERT INTO setting SET image1='$image1',image2='$image2', image3 = '$image3', image4='$image4', background='$background', logo='$logo'");
                $JSON = array(
                    "title" => "Lưu ảnh thành công",
                    "text" => "Chờ reload",
                    "type" => "success",
                    "reload" => "true",
                    "time" => $time_swal
                );
                die(json_encode($JSON, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
            }
          break;
          
        }
    }

?> 