<?php
include '../config.php';
header('Location: '.$domain.'/404.html');
?>