<?php
	session_start();
    require_once("../../config.php");
	if(empty($_POST['card_type']) || empty($_POST['card_amount']) || empty($_POST['serial']) || empty($_POST['pin'])){
        $JSON = array(
            "title" => "Yêu cầu thông tin",
            "text" => "Bạn chưa điền đầy đủ thông tin",
            "type" => "info",
        );
        die(json_encode($JSON, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    }
    $type = addslashes(intval($_POST['card_type']));
    $amount = addslashes(intval($_POST['card_amount']));
    $seri = addslashes(intval($_POST['serial']));
    $pin = addslashes(intval($_POST['pin']));
    if(strlen($seri) < 6 || strlen($seri) > 20 || strlen($pin) < 10 || strlen($seri) > 20){
        $JSON = array(
            "title" => "Yêu cầu mã",
            "text" => "Bạn cần nhập 10 > 20 kí tự",
            "type" => "info",
        );
        die(json_encode($JSON, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
   }
   $kiemtra_the = mysqli_num_rows(mysqli_query($kunloc,"SELECT id FROM gachthe WHERE code = '$pin' AND serial='$seri'"));
   if(empty($pin) || empty($seri)) {
        $JSON = array(
            "title" => "Yêu cầu mã",
            "text" => "Bạn cần nhập 10 > 20 kí tự",
            "type" => "info",
        );
        die(json_encode($JSON, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));

   }
   if($kiemtra_the == 1){
        $JSON = array(
            "title" => "Thẻ đã tồn tại!",
            "text" => "Vui lòng không gửi quá nhiều lần",
            "type" => "error",
        );
        die(json_encode($JSON, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
   }
   $tinhtrang= 'Đợi Xử Lý';
   mysqli_query($kunloc,"INSERT INTO gachthe (code,serial,menhgia, loaithe, username, tinhtrang) VALUES ('$pin','$seri','$amount','$type','$username','$tinhtrang')");
   $JSON = array(
        "title" => "Gửi thành công!",
        "text" => "Xin chờ 24h để xử lý",
        "type" => "success",
        "reload" => "true",
        "time" => $time_swal
    );
    die(json_encode($JSON, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    
 
?>