<?php
    session_start();
    require_once("../../config.php");
    if(isset($_REQUEST['type']) && $_POST['id']){
        $Case_ = $_REQUEST['type'];
        switch($Case_){
            #----------------------------------------------------------------
            case 'duyet':
                $i = intval($_POST['id']);
                if($username != $admin){
                    $JSON = array(
                        "title" => "Bạn không có quyền",
                        "text" => "Không thể duyệt id này",
                        "type" => "error"
                    );
                    die(json_encode($JSON, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
                }
                $SQL_ = mysqli_query($kunloc,"SELECT * FROM gachthe WHERE id = '$i'");
                $Napthe_ = mysqli_fetch_object($SQL_);
                if(mysqli_num_rows($SQL_) == 1){
                    if(mysqli_num_rows(mysqli_query($kunloc,"SELECT * FROM log_nap_the WHERE username = '{$Napthe_->username}'"))){
                        mysqli_query($kunloc,"UPDATE log_nap_the SET VND = VND +  ".$Napthe_->menhgia.",date='$today' WHERE username = '{$Napthe_->username}'");
                    }else{
                        mysqli_query($kunloc,"INSERT INTO log_nap_the(username,VND,date) VALUES ('{$Napthe_->username}','{$Napthe_->menhgia}','$today')");
                    }
                    $loai_ = 'Gạch chậm';
                    mysqli_query($kunloc,"INSERT INTO lich_su_hoat_dong(username,VND,date,loai) VALUES('{$Napthe_->username}','".number_format($Napthe_->menhgia)."','$today','$loai_')");
                    $tinhrang = 'Đã duyệt';
                    mysqli_query($kunloc,"UPDATE gachthe SET tinhtrang = '$tinhrang' WHERE id = '$i'");
                    mysqli_query($kunloc,"UPDATE account SET VND = VND + ".$Napthe_->menhgia." WHERE username = '{$Napthe_->username}' ");
                }
                $JSON = array(
                    "title" => "Đã duyệt thành công",
                    "text" => "Chờ reload...",
                    "type" => "success",
                    "reload" => "true",
                    "time" => $time_swal
                );
                die(json_encode($JSON, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
            break;
            #----------------------------------------------------------------
            case 'remove':
                $i = intval($_POST['id']);
                if($username != $admin){
                    $JSON = array(
                        "title" => "Bạn không có quyền",
                        "text" => "Không thể duyệt id này",
                        "type" => "error"
                    );
                    die(json_encode($JSON, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
                }
                $tinhrang = 'Từ chối';
                mysqli_query($kunloc,"UPDATE gachthe SET tinhtrang = '$tinhrang' WHERE id = '$i'");
                #mysqli_query($kunloc,"DELETE FROM gachthe WHERE id= '$i'");
                $JSON = array(
                    "title" => "Đã xóa thành công",
                    "text" => "Chờ reload...",
                    "type" => "success",
                    "reload" => "true",
                    "time" => $time_swal
                );
                die(json_encode($JSON, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
            break;
        }
    }else{
        $JSON = array(
            "title" => "Bạn không có quyền",
            "text" => "Không thể duyệt id này",
            "type" => "error"
        );
        die(json_encode($JSON, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    }
?>