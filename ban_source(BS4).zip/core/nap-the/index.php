<div class="row">
<div class="col-lg-5">
    <div class="card">
         <div class="card-header d-flex justify-content-between">
            <div class="header-title"><h4 class="card-title">Nạp thẻ chậm 24h</h4></div>
         </div>
         <form action="javascript:volid();" method="POST">
            <div class="card-body">
            <div class="irow row" >
                  <div class="col-sm-6 select">
                     <div class="form-group is-empty">
                        <label for=""> Loại thẻ:</label>
                        <select class="custom-select" id="card_type" name="card_type" >
                           <option value="0">Chọn loại thẻ</option>
                           <option value="1">Viettel</option>
                           <option value="2">Vinafone</option>
                           <option value="3">Mobifone</option>
                        </select>
                     </div>
                  </div>
                  <div class="col-sm-6">
                     <div class="form-group is-empty">
                        <label for=""> Mệnh giá:</label>
                        <select class="custom-select" id="card_amount" name="card_amount">
                           <option value="">Chọn mệnh giá</option>
                           <option value="10000">10.000</option>
                           <option value="20000">20.000</option>
                           <option value="30000">30.000</option>
                           <option value="50000">50.000</option>
                           <option value="100000">100.000</option>
                           <option value="200000">200.000</option>
                           <option value="300000">300.000</option>
                           <option value="500000">500.000</option>
                        </select>
                     </div>
                  </div>
               </div>
               <div class="irow row">
                  <div class="col-sm-6 select">
                     <div class="form-group is-empty">
                        <label for=""> Số Seri:</label>
                        <input type="number" class="custom-select" name="serial" id="serial"  placeholder="Vui lòng nhập mã seri..."/>
                     </div>
                  </div>
                  <div class="col-sm-6">
                     <div class="form-group is-empty">
                        <label for=""> Mã thẻ:</label>
                        <input type="number" class="custom-select" name="pin" id="pin" placeholder="Vui lòng nhập mã pin..." />
                     </div>
                  </div>
               </div>
               <div class="text-center">
                    <button type="submit" name="submit" id="submit" style="border-radius:10px" class="btn-sm btn btn-block btn-outline-success">Gửi Thẻ Chờ Duyệt</button>
               </div>
            </div>
        </form>

      </div>
    </div>
    <!-- /. -->
<div class="col-lg-7">
    <div class="card">
         <div class="card-header d-flex justify-content-between">
            <div class="header-title"><h4 class="card-title">Lịch sử nạp thẻ</h4></div>
         </div>
         <div class="card-body">
         <div class="table-responsive">
              <table id="lich_su_nap_the" class="table table-bordered nowrap scroll-horizontal-vertical">
               <thead>
                 <tr>
                     <th>STT</th>
                     <?php if($username == $admin){ ?>
                     <th>Duyệt</th>
                     <th>Code</th>
                     <th>Pin</th>
                     <?php } ?>
                     <th>Tên</th>
                     <th>Mệnh giá</th>
                     <th>Loại thẻ</th>
                     <th>Tình Trạng</th>
                     
                  </tr>
                  <tbody>
                     <?php
                        $getloaithe = array('','Viettel','Vinaphone','Mobifone');
                        $SQL_thecao = mysqli_query($kunloc,"SELECT * FROM gachthe");
                        while($kunloc_thecao = mysqli_fetch_assoc($SQL_thecao)){ ?>
                    <tr id="table_<?= $kunloc_thecao['id']; ?>">
                        <td><?= $kunloc_thecao['id']; ?></td>
                        <?php if($username == $admin){ ?>
                        <td>
						    <a href="#" onclick="duyet(<?= $kunloc_thecao['id']; ?>)"><span class="badge badge-success">Xác Nhận </span></a>  
						    <a href="#" onclick="remove(<?= $kunloc_thecao['id']; ?>)"><span class="badge badge-danger">Từ Chối</span></a>
						</td>
                        <td><span class="badge badge-danger"><?= $kunloc_thecao['code']; ?> </span></td>
						<td><span class="badge badge-success"><?= $kunloc_thecao['serial']; ?> </span></td>
    
                        <?php } ?>
                        <td><?= $kunloc_thecao['username']; ?></td>
                        <td><span class="badge badge-warning"><?= number_format($kunloc_thecao['menhgia']); ?> <sup><font color="black">VNĐ</font></sup></span></td>
                        <td><span class="badge badge-success"><?= $getloaithe[$kunloc_thecao['loaithe']]; ?></span></td>
                        <td><span class="badge badge-primary"><?= $kunloc_thecao['tinhtrang']; ?></span></td>
                        
                     </tr>
                     <?php } ?>
                  </tbody>
            </table>
         </div>

         </div>


      </div>
    </div>
<!-- /./ -->
 </div>
 <script type="text/javascript">
 $(document).ready(function() {
    var table = $('#lich_su_nap_the').DataTable( {
    lengthChange: true,
      "aaSorting": [
                [0, "desc"]
            ],
        "iDisplayLength": 3,
        "aLengthMenu": [
            [3, 10, 20, 30, 40, 50, 100, 200, 500, 1000, -1],
            [3, 10, 20, 30, 40, 50, 100, 200, 500, 1000, "Tất cả"]
        ],
        "oLanguage": {
            "lengthMenu": "Hiển thị _MENU_ mục",
            "zeroRecords": "Không tìm thấy kết quả",
            "sInfo": "Hiển Thị _START_ trong _END_ của _TOTAL_ mục",
            "sEmptyTable": "Không có dữ liệu trong bảng",
            "sInfoEmpty": "Hiển Thị 0 trong 0 của 0 bảng",
            "sInfoFiltered": "(Đã lọc từ _MAX_ tổng bảng)",
            "sInfoPostFix": "",
            "sDecimal": "",
            "sThousands": ",",
            "sLengthMenu": "Hiển thị _MENU_ mục",
            "sLoadingRecords": "Đang tải...",
            "sProcessing": "Processing...",
            "sSearch": "Tiềm kiếm:",
            "sZeroRecords": "Không tìm thấy kết quả",
            "sSearchPlaceholder": "Nhập từ cần tìm...",
            "oPaginate": {
                "sFirst": "ĐẦU",
                "sLast": "Cuối",
                "sNext": "Tiếp",
                "sPrevious": "Trước"
            },
            "oAria": {
                "sSortAscending": ": ASC Tăng Dần",
                "sSortDescending": ": DESC Giảm Dần"
            }
        }
  })
   table.buttons().container() .appendTo( '#example_wrapper .col-md-6:eq(0)' );
})
$('#submit').click(function(){
   var card_type = $('#card_type').val();
   var card_amount = $('#card_amount').val();
   var serial = $('#serial').val();
   var pin = $('#pin').val();
   if (card_type == '' || card_amount == '' || serial == '' || pin == '') {
        Swal.fire("Chưa điền đầy đủ","Còn thiếu gì đó! Xin hãy điền đầy đủ","info");
        return false;
   }
   $("#progressbar").show();
   $('#submit').prop('disabled', true).html('<i class="fa fa-refresh fa-spin" style="font-size:11px"></i> Đang Kiểm Tra...').attr('disabled','disabled');
   $.post('core/nap-the/xuly.php', { 
       card_type: card_type,
       card_amount:card_amount, 
       serial:serial,
       pin:pin
   }, function(data) {
       setTimeout(function(){ 
            Data = JSON.parse(data);
            if(Data.reload){
                setTimeout(() => { location.reload() }, Data.time)
            }
            Swal.fire(Data.title, Data.text,Data.type);
       	    $("#progressbar").hide();
       	    $('#submit').prop('disabled', false).html('Gửi Thẻ Chờ Duyệt');
       }, 0);
   })

})
function duyet(id) {
 		const swalWithBootstrapButtons = Swal.mixin({
  customClass: {
    confirmButton: 'm-1 btn-sm btn-success',
    cancelButton: 'm-1 btn-sm btn-danger'
  },
  buttonsStyling: true
})
swalWithBootstrapButtons.fire({
  title: 'Xác nhận đã duyệt?',
  text: "Bạn chắc chắn muốn duyệt!",
  icon: 'info',
  showCancelButton: true,
  confirmButtonText: 'Đồng ý',
  cancelButtonText: 'Hoàn tác',
  reverseButtons: false
}).then((result) => {
  if (result.value) {
    $.post('core/nap-the/setting.php', { 
           type: 'duyet', 
           id: id
        }, function(data) {
            Data = JSON.parse(data);
            if(Data.reload){
                setTimeout(() => { location.reload() }, Data.time)
            }
            Swal.fire(Data.title, Data.text,Data.type);
    })
  } 
})
return false;
}
function remove(id) {
 		const swalWithBootstrapButtons = Swal.mixin({
  customClass: {
    confirmButton: 'm-1 btn-sm btn-success',
    cancelButton: 'm-1 btn-sm btn-danger'
  },
  buttonsStyling: true
})
swalWithBootstrapButtons.fire({
  title: 'Xác nhận từ chối thẻ?',
  text: "Bạn chắc chắn muốn từ chối!",
  icon: 'info',
  showCancelButton: true,
  confirmButtonText: 'Đồng ý',
  cancelButtonText: 'Hoàn tác',
  reverseButtons: false
}).then((result) => {
  if (result.value) {
    $.post('core/nap-the/setting.php', { 
           type: 'remove', 
           id: id
        }, function(data) {
            Data = JSON.parse(data);
            if(Data.reload){
                setTimeout(() => { location.reload() }, Data.time)
            }
            Swal.fire(Data.title, Data.text,Data.type);
    })
  } 
})
return false;
}
</script>