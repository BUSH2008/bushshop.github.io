<div class="row">
   <div class="col-lg-6" style="visibility: visible; animation-duration: 1s; animation-name: fadeInLeft;">
      <div class="card">
         <div class="card-header text-center"><i class="fa fa-1x fa-asterisk fa-spin text-success"></i> HƯỚNG DẪN NẠP TIỀN TÀI KHOẢN</div>
            <div class="card-body">
                <!-- /./ -->
                 <div class="table-responsive d-none d-sm-block">
                     <div class="card profile-card-1" style="visibility: visible; animation-duration: 1s; animation-name:flash;">
                     <img src="https://static.mservice.io/img/momo-upload-api-tin-tuc-su-kien-181015180150.jpg" class="d-none d-xl-block img-fluid" alt="profile-image"/>
                  </div>
               </div>
               <!-- /./ -->  
              <div class="d-block d-sm-none form-group text-center">
                <img src="https://www.upsieutoc.com/images/2020/10/03/120728836_358312938688355_6932053722983812094_n.jpg" width="auto" height="150px">
                </div>
                <div class="form-group">
                <div class="table-responsive">
                <table class="table table-bordered table-hover">
                    <thead class="">
                        <th>CHỦ TÀI KHOẢN</th>
                        <th>SỐ TÀI KHOẢN</th>
                        <th>CHI NHÁNH</th>
                    </thead>
                    <tr>
                        <td><b style="color:blue">NGUYỄN THÀNH LỘC</b></td>
                        <td><b style="color:red">0364834835</b></td>
                        <td><b style="color:green">HỒ CHÍ MINH</b></td>
                    </tr>
                </table>
                </div>  </div>  
                <!--/./ -->
                <div class="form-group row">
                    <div class="input-group col-sm-2"><b>CONTENT:</b></div>
                    <div class="input-group col-sm-10">
                        <input readonly class="custom-select" id="copy" value="naptien <?= $username ?>">
                            <div class="input-group-append">
                                <button onclick="copy()" type="button" class="btn btn-success">COPY</button>
                            </div>
                        </div>
                </div>  
            </div>
            <div class="card-footer">
                
                <h5 class=""><i class="fa fa-1x fa-asterisk fa-spin text-success"></i> Chuyển khoản với cú pháp: <h style="color:red">naptien <?= $username ?></h></h5>
                <h5 class=""><i class="fa fa-1x fa-asterisk fa-spin text-success"></i> Qua STK: <h style="color:red">0364834835</h></h5>
                <div class="form-group mt-2">
                    <h6>Sau khi chuyển tiền vào số tài khoản trên. Hệ thống sẽ bắt đầu kiểm tra và cộng tiền vào tài khoản của bạn.
                    <br>Cần tối thiểu <font color="red">10 - 60 </font> giây để hệ thống xử lý!!!!</h6>
                </div>
               </div>
               
      </div>
   </div>
<!-- Panel 2 -->
<div class="col-lg-6" style="visibility: visible; animation-duration: 1s; animation-name: fadeInRight;">
   <div class="card">
      <div class="card-header text-center"><i class="fa fa-1x fa-asterisk fa-spin text-success"></i> Lịch Sử Chuyển Khoản</div>
      <div class="card-body">
        <!--- /./ -->
        <div class="table-responsive">
         <table id="momo" class="table table-bordered dataTable" role="grid" aria-describedby="default-datatable_info">
               <thead>
                  <tr>
                      <th scope="col">TYPE</th>
                      <th scope="col">Nội dung giao dịch</th>
                      <th scope="col">Số tiền giao dịch</th>
                      <th scope="col">Thông tin người gửi</th>
                  </tr>
               <tbody>
                   <?php
                   if($username == $admin){
                       $SQL = mysqli_query($kunloc,"SELECT * FROM momo");
                   }else{
                      $SQL = mysqli_query($kunloc,"SELECT * FROM momo WHERE username = '$username'");  
                   }
                   while ($echo = mysqli_fetch_assoc($SQL)){
				    ?>
                    <tr>
                      <td class="text-center"> 
                      <span class="column">
                         <img width="50" style="border-radius:50px" src="https://static.mservice.io/blogscontents/momo-upload-api-push-momo-avatar-190131152912.png"><br>
                        MOMO
                      </span> 
                      </td>
                      <td>
                      Mã giao dịch:<b style="color:#151515"><?= $echo['ma_giao_dich']; ?></b><br>
                      Content: <h6 class="text-danger"><?= $echo['content']; ?></h6>
                      </td>
                      <td>
                      Ngày: <b style="color:green"><?= $echo['date']; ?></b><br>
                      
                      Số tiền thanh toán: <b style="color:red"><?= $echo['so_tien']; ?></b> VND<br>
                      </td>
                      <td>

                      Số điện thoai: #<b class="text-danger"><?= $echo['so_dien_thoai']; ?></b>
                      <br>
                      Gửi từ: <b style="color:#151515"><?php 
                          if($echo['username'] == ''){
                            echo 'Trống';
                          }else{
                           echo  $echo['username'];
                          }
                      ?></b>
                      </td>
                    </tr>
                    <?php } ?>
               </tbody>
               </thead>
            </table>
         </div>
      </div>
<!-- /./ -->
</div>
</div>
</div> 
<!-- ROW -->
<script type="text/javascript">
$(document).ready(function() {
    var table = $('#momo').DataTable( {
    lengthChange: true,
    "aaSorting": [
            [0, "desc"]
        ],
        "iDisplayLength": 5,
        "aLengthMenu": [
            [5, 10, 20, 30, 40, 50, 100, 200, 500, 1000, -1],
            [5, 10, 20, 30, 40, 50, 100, 200, 500, 1000, "Tất cả"]
        ],
        "oLanguage": {
            "lengthMenu": "Hiển thị _MENU_ mục",
            "zeroRecords": "Không tìm thấy kết quả",
            "sInfo": "Hiển Thị _START_ trong _END_ của _TOTAL_ mục",
            "sEmptyTable": "Không có dữ liệu trong bảng",
            "sInfoEmpty": "Hiển Thị 0 trong 0 của 0 bảng",
            "sInfoFiltered": "(Đã lọc từ _MAX_ tổng bảng)",
            "sInfoPostFix": "",
            "sDecimal": "",
            "sThousands": ",",
            "sLengthMenu": "Hiển thị _MENU_ mục",
            "sLoadingRecords": "Đang tải...",
            "sProcessing": "Processing...",
            "sSearch": "Tiềm kiếm:",
            "sZeroRecords": "Không tìm thấy kết quả",
            "sSearchPlaceholder": "Nhập từ cần tìm...",
            "oPaginate": {
                "sFirst": "ĐẦU",
                "sLast": "Cuối",
                "sNext": "Tiếp",
                "sPrevious": "Trước"
            },
            "oAria": {
                "sSortAscending": ": ASC Tăng Dần",
                "sSortDescending": ": DESC Giảm Dần"
            }
        }
  });
   table.buttons().container().appendTo( '#example_wrapper .col-md-6:eq(0)' );
})
function copy(){
     var noidung = $('#copy').select();
     document.execCommand("copy");
     Swal.fire('Đã copy nội dung','Đã copy access token','success')
     return false;
 }
</script>