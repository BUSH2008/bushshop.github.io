<?php
session_start();
require_once("../../config.php");
#if($_GET) $_POST = $_GET;
if(empty($_POST['code'])){
 exit();
}
if(isset($_POST['code'])){
    $code = mysqli_real_escape_string($kunloc,$_POST['code']);
    if($username = $admin){
      $SQL = mysqli_fetch_object(mysqli_query($kunloc,"SELECT * FROM blog WHERE code = '$code' "));
    }else{
      $SQL = mysqli_fetch_object(mysqli_query($kunloc,"SELECT * FROM blog WHERE username = '$username' AND code = '$code' "));
    }
    if($SQL->code != $code){ ?>
    <center><b style="color:red">Bạn không có quyền sửa bài viết này. Vui lòng liên hệ <a href="https://facebook.com/<?= $facebook ?>">Admin</a></b></center>
    <?php }else{ ?>
              <form method="POST">
                  <input id="code" type="number" class="d-none" value="<?= $SQL->code ?>"/>
                  <div class="form-group">
                    <label for="">TIÊU ĐỀ BÀI VIẾT (<h style="color:red">CHỦ ĐỀ BÀI VIẾT</h>)</label>
                    <input id="title" type="text" class="custom-select" value="<?= $SQL->title ?>" placeholder="Điền tiêu đề bài viết" required>
                  </div>
                  <!-- /./ -->
            <div class="irow row">
                <div class="col-sm-6">
                    <div class="form-group">
                        <label for="">URL LIVE(<b style="color:red">DEMO URL</b>)</label>
                        <input id="demo" type="text" class="custom-select" value="<?= $SQL->link ?>" placeholder="ex: https://domain.com" required>
                    </div>
                    </div>
                    <!-- /./ -->
                <div class="col-sm-6">
                    <div class="form-group">
                      <label for="">URL DOWNLOAD(<b style="color:red">DOWNLOAD URL</b>)</label>
                      <input id="download" type="text" class="custom-select" value="<?= $SQL->download ?>" placeholder="ex: https://download.zip" required>
                    </div>
               </div>
            </div>
            <!-- /./ -->
            <div class="irow row">
               <div class="col-sm-6">
                 <div class="form-group">
                    <label for="">THÊM LINK HÌNH ẢNH DEMO (<b style="color:red">IMG,PNG</b>)</label>
                    <input id="image" type="text" class="custom-select" value="<?= $SQL->image ?>"  placeholder="ex: https://www.upsieutoc.com/images/2020/10/03/120728836_358312938688355_6932053722983812094_n.jpg" required>
                  </div>
              </div>
            <!-- /./ -->
            <div class="col-sm-6">
                  <div class="form-group">
                    <label for="">CHỌN CHẾ ĐỘ SOURCE:</label>
                      <select class="custom-select" id="type">
                         <?php if($SQL->gia == 0){ ?>
                         <option value="1" selected="">MIỄN PHÍ (SHARE CODE)</option>
                         <?php }else{ ?>
                          <option value="2" selected="">ĐĂNG BÁN (SELL CODE)</option>
                         <?php } ?>
                      </select>
                  </div>
                  <div class="form-group" style="display:none;" id="form-gia">
                    <label for="">GIÁ SOURCE (<b style="color:red">Min 10.000 - Max: 1.500.000 VND</b>)</label>
                    <input id="gia" type="number" class="custom-select" value="<?= $SQL->gia ?>" placeholder="10.000 VND - 1.500.000 VND" required>
                  </div>
             </div>
           </div>
            <!-- /./ -->
              <div class="form-group">
                  <label for="">NỘI DUNG BÀI VIẾT:</label>
                  <textarea id="html" type="text" class="custom-select ckeditor"><?= $SQL->html ?></textarea>
                </div>
                <div class="form-group">
                  <button type="submit" id="submit" class="btn-sm btn btn-outline-dark">LƯU BÀI VIẾT CỦA BẠN</button>
                </div>
              </form>
</div>
<!-- end row ADS /./ -->
<script src="/assets/editor/ckeditor.js"></script>
<script type="text/javascript">
setInterval(() => {
  var editor = CKEDITOR.replace('html');
  checkout()
}, 1e3);
function checkout(){
      var type = document.getElementById('type').value;
      if(type == 1){
        $('#form-gia').hide()
      }
      if(type == 2){
        $('#form-gia').show()
      }
}
$('#submit').click(function(){
   var code = $('#code').val();
   var title = $('#title').val();
   var image = $('#image').val();
   var demo = $('#demo').val();
   var download = $('#download').val();
   var html = CKEDITOR.instances.html.getData();
   var type = $('#type').val();
   var gia = $('#gia').val();
   if(type == 1){
      var vnd = 0;
   }else if(type == 2){
      var vnd = gia;
   }
   if(code == '' || title == '' || type == '' || html == '' || demo == '' || download == '' || image == ''){
        Swal.fire("Chưa điền đầy đủ","Chưa điền đầy đủ bài viết","error");
        return false;
   }
   $('#submit').prop('disabled', true).html('Đang Kiểm Tra...');
       $.post('core/them-source/ajax.php', { 
          code:code,
          demo:demo,
          download:download,
          image:image,
          title: title,
          html: html,
          gia: vnd
        }, function(data) {
            Data = JSON.parse(data);
            if(Data.reload){
                setTimeout(() => { location.reload() }, Data.time)
            }
            $('#submit').prop('disabled', false).html('Hoàn Thành Cài Đặt');
            Swal.fire(Data.title, Data.text,Data.type);
            return false;
           	
       })
})
</script>
<?php } } ?>