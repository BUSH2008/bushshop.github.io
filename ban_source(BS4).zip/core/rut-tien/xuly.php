<?php
	session_start();
    require_once("../../config.php");
	if(empty($_POST['loai']) || empty($_POST['taikhoan']) || empty($_POST['chinhanh']) ||  empty($_POST['menhgia']) ||  empty($_POST['password'])){
        $JSON = array(
            "title" => "Yêu cầu thông tin",
            "text" => "Bạn chưa điền đầy đủ thông tin",
            "type" => "info",
        );
        die(json_encode($JSON, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
	}
	$value = array("","ATM","ViettelPay","Zing","Garena","Moblie","Momo");
	$gia = array(0,50000,100000,200000,500000);
	$loai = $value[addslashes($_POST['loai'])];
	$taikhoan = addslashes($_POST['taikhoan']);
	$chinhanh = addslashes($_POST['chinhanh']);
	$menhgia = $gia[addslashes($_POST['menhgia'])];
	$password = addslashes(md5($_POST['password']));
    $pass = mysqli_fetch_assoc(mysqli_query($kunloc,"SELECT * FROM account WHERE password = '$password' AND username = '$username'"))['password'];
	if($vnd < $menhgia){
		$JSON = array(
            "title" => "Số dư không đủ",
			"text" => "Vui lòng nạp thêm tiền",
			"type" => "error",
			"reload" => "true",
			"time" => $time_swal
        );
        die(json_encode($JSON, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));

	}else if($menhgia < 50000 || $menhgia > 500000){

        $JSON = array(
            "title" => "Cú Pháp Không Hợp Lệ",
            "text" => "Xin hãy kiểm tra lại",
            "type" => "error",
        );
        die(json_encode($JSON, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
	}
	if($password != $pass){
        $JSON = array(
            "title" => "Mật khẩu không đúng",
            "text" => "Mật khẩu bạn nhập không chính xác",
            "type" => "error",
        );
        die(json_encode($JSON, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
	}
	if(mysqli_num_rows(mysqli_query($kunloc,"SELECT * FROM rut_tien WHERE taikhoan = '$taikhoan' AND menhgia = '$menhgia' AND username = '$username'"))){
            $JSON = array(
                "title" => "Yều cầu này đã tồn tại",
                "text" => "Xin đợi 5 phút rồi làm lại",
                "type" => "error",
            );
            die(json_encode($JSON, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    }else{
       $insert_post = mysqli_query($kunloc,"INSERT INTO rut_tien(loai, taikhoan, chinhanh, menhgia, username, trangthai, date) VALUES ('$loai','$taikhoan','$chinhanh', '$menhgia', '$username','fail' ,'$today')");
       mysqli_query($kunloc,"UPDATE account SET VND = VND - $menhgia WHERE username = '$username' ");
       $JSON = array(
            "title" => "Yêu cầu thành công",
            "text" => "Xin đợi 24h để duyệt",
            "type" => "success",
            "reload" => "true",
            "time" => $time_swal
        );
       die(json_encode($JSON, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    }

?>