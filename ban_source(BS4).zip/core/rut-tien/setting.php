<?php
    session_start();
    require_once("../../config.php");
    if(isset($_REQUEST['type']) && $_POST['id']){
        $Case_ = $_REQUEST['type'];
        switch($Case_){
            case 'duyet':
                $i = intval($_POST['id']);
                if($username != $admin){
                    $JSON = array(
                        "title" => "Bạn không có quyền",
                        "text" => "Không thể duyệt id này",
                        "type" => "error"
                    );
                    die(json_encode($JSON, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
                }
                $kiem_tra = mysqli_query($kunloc,"SELECT * FROM rut_tien WHERE id = '$i' ");
                if(mysqli_num_rows($kiem_tra) == 1){
                    $Get_Info = mysqli_fetch_object($kiem_tra);
                    mysqli_query($kunloc,"UPDATE rut_tien SET trangthai = 'success' WHERE id = '{$Get_Info->id}' ");
                    #------------------------
                    if(mysqli_num_rows(mysqli_query($kunloc,"SELECT * FROM log_rut_tien WHERE username = '{$Get_Info->username}'"))){
                        mysqli_query($kunloc,"UPDATE log_rut_tien SET VND = VND + ".$Get_Info->menhgia." WHERE username= '{$Get_Info->username}' ");
                    }else{
                        mysqli_query($kunloc,"INSERT INTO log_rut_tien(username,VND,date)  VALUES('{$Get_Info->username}','{$Get_Info->menhgia}','$today')");
                    }
                    $JSON = array(
                        "title" => "Đã duyệt thành công",
                        "text" => "Chờ reload...",
                        "type" => "success",
                        "reload" => "true",
                        "time" => $time_swal
                    );
                    die(json_encode($JSON, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
                }else{
                    $JSON = array(
                        "title" => "Giao dịch không tồn tại",
                        "text" => "Xin thử lại",
                        "type" => "error",
                        "reload" => "true",
                        "time" => $time_swal
                    );
                    die(json_encode($JSON, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
                }
            break;
            #----------------------------------------------------------------
            case 'remove':
                $i = intval($_POST['id']);
                if($username != $admin){
                    $JSON = array(
                        "title" => "Bạn không có quyền",
                        "text" => "Không thể duyệt id này",
                        "type" => "error"
                    );
                    die(json_encode($JSON, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
                }
                mysqli_query($kunloc,"DELETE FROM rut_tien WHERE id = '$i'");
                $JSON = array(
                    "title" => "Đã xóa thành công",
                    "text" => "Chờ reload...",
                    "type" => "success",
                    "reload" => "true",
                    "time" => $time_swal
                );
                die(json_encode($JSON, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
            break;
        }
    }else{
        $JSON = array(
            "title" => "Bạn không có quyền",
            "text" => "Không thể duyệt id này",
            "type" => "error"
        );
        die(json_encode($JSON, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    }
?>