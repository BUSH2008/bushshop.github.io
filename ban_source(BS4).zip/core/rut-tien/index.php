<div class="row">
<div class="col-lg-5">
    <div class="card">
         <div class="card-header d-flex justify-content-between">
            <div class="header-title"><h4 class="card-title">RÚT TIỀN VỀ TÀI KHOẢN</h4></div>
         </div>
         <form action="javascript:volid();" method="POST">
            <div class="card-body">
                <p align="left">
            	<i class="fa fa-warning" aria-hidden="true"></i> Khi đã đủ số xu nhất định bạn có thể rút tiền về tài khoản ngân hàng hoặc thẻ game,....<br>
                <i class="fa fa-warning" aria-hidden="true"></i> <font color="red">Lưu ý:</font> Số tiền tối thiểu rút <font color="orange">50,000</font> VND.<br>
                <!--- /./ -->
                  <div class="col-sm-13 mt-2">
                     <div class="form-group has-default has-feedback">
                         <div class="form-group">
                           <label class="form-label" style="color:black">Chọn Phương Thức Thanh Toán</label>
                           <select class="custom-select" id="loai" required>
                                    <option value="1">Ngân Hàng</option>
                                    <option value="2">Viettel Pay</option>
                                    <option value="3">Thẻ Zing</option>
                                    <option value="4">Thẻ Garena</option>
                                    <option value="5">Nạp Tiền Điện Thoại</option>
                                    <option value="6">Ví Điện Tử Momo</option>
                            </select>
                           </div>
                         
                     </div>
                  </div>
                   <!-- /./ -->
                 
                  <div class="col-sm-13">
                     <div class="form-group has-default has-feedback">
                        <div class="form-group">
                           <label class="form-label" style="color:black">Số Tài Khoản</label>
                           <input type="number" min="1" id="taikhoan" class="custom-select" data-toggle="tooltip" title="Số tài khoản" data-original-title="Số tài khoản" placeholder="Vui lòng nhập số tài khoản..." required>
                        </div>
                     </div>
                  </div>
                   <!-- /./ -->
                  <div class="col-sm-13">
                     <div class="form-group has-default has-feedback">
                       <div class="form-group">
                           <label class="form-label" style="color:black">Chi Nhánh</label>
                           <input type="text" id="chinhanh" class="custom-select" data-toggle="tooltip" title="Chi nhánh" data-original-title="Chi nhánh" placeholder="Vui lòng nhập Chi nhánh.." required>
                     </div>
                  </div>
                  </div>
                  <!-- /./ -->
                  <div class="col-sm-13">
                     <div class="form-group has-default has-feedback">
                       <div class="form-group">
                           <label class="form-label" style="color:black">Mệnh Gía</label>
                           <select class="custom-select" id="menhgia" required>
                                    <option value="1">50.000 VND</option>
                                    <option value="2">100.000 VND</option>
                                    <option value="3">200.000 VND</option>
                                    <option value="4">500.000 VND</option>
                            </select>
                     </div>
                  </div>
                  </div>
                  <!-- /./ -->
                  <div class="col-sm-13">
                     <div class="form-group has-default has-feedback">
                       <div class="form-group">
                           <label class="form-label" style="color:black">Mật Khẩu Đăng Nhập</label>
                           <input type="password" id="password" class="custom-select" placeholder="Vui lòng nhập mật khẩu." required>
                     </div>
                  </div>
                  </div>
                 <!-- /./ -->
                  <div class="col-sm-13">
                       <div class="form-group has-default has-feedback">
                         <button type="submit" name="submit" id="submit" class="btn-sm btn btn-outline-success" data-toggle="tooltip" title="Nhấp vào đây">RÚT TIỀN</button>
                        </div> 
                    <p align="left">
                        <i class="fa fa-lightbulb-o"></i> Lưu Ý:<br>
						+ Các yêu cầu rút tiền cần tối thiểu 4h-24h để hoàn thành.<br>
						+ Vui lòng điền chính xác các trường ở trên đẻ tránh mất tiền oan
					</p>
                  </div>
            <!-- /./ -->
               </div>
            </form>

      </div>
</div>
<!-- panel 2 -->
<div class="col-lg-7">
    <div class="card">
         <div class="card-header d-flex justify-content-between">
            <div class="header-title"><h4 class="card-title">RÚT TIỀN VỀ TÀI KHOẢN</h4></div>
         </div>
         <div class="card-body">
         <div class="table-responsive">
         <table id="lichsu" class="table table-striped nowrap scroll-horizontal-vertical">
               <thead>
                  <tr>
                     <th>Tùy Chọn</th>
                     <th>Ngày</th>
                     <th>Trạng thái</th>
                     <th>Người Rút</th>
                     <th>Sô Tiền</th>
                     <th>Số tài khoản</th>
                     <th>Chi Nhánh</th>
                     <th>Hình Thức</th>
                  </tr>
                <tbody>
                <?php
                     if($_SESSION['username'] == 'kunloc'){
                         $SQL = mysqli_query($kunloc,"SELECT * FROM rut_tien");
                     }else{
                         $SQL = mysqli_query($kunloc,"SELECT * FROM rut_tien WHERE username = '$username'");
                     }
                     while ($kunloc = mysqli_fetch_assoc($SQL)):?>
                  <tr>
                     <td>
                         <?php if($username == $admin){ ?>
                         <span href="#" onclick="duyet(<?= $kunloc['id']; ?>)" class="badge badge-success" data-toggle="tooltip" title="Duyệy">Duyệt</span>
                         <?php } ?>
                         <span href="#" onclick="remove(<?= $kunloc['id']; ?>)" class="badge badge-danger" data-toggle="tooltip" title="Nhấp vào để xóa ID">Gỡ Lịch Sử</span>
                     
                     </td>
                    <td><b data-toggle="tooltip" title="Ngày rút tiền" style="color:blue"><?= $kunloc['date']; ?></b></td>
                     <td>
                        <?php 
                         if($kunloc['trangthai'] == 'success'){
                            echo '<h data-toggle="tooltip" title="Trạng thái" style="color:green">Hoàn Thành</h>'; 
                         }else if($kunloc['trangthai'] == 'fail'){
                            echo '<h data-toggle="tooltip" title="Trạng thái" style="color:blue">Đợi Duyệt</h>'; 
                         } ?>
                    </td>
                     <td><b data-toggle="tooltip" title="Người mua" style="color:blue"><?= $kunloc['username']; ?></b></td>
                     <td><b data-toggle="tooltip" title="Số tiền rút" style="color:red"><?= number_format($kunloc['menhgia']); ?> </b>VND</td>
                     <td><b data-toggle="tooltip" title="Số Tài Khoản" style="color:green"><?= $kunloc['taikhoan']; ?></b></td>
                     <td><b data-toggle="tooltip" title="Chi Nhánh" style="color:blue"><?= $kunloc['chinhanh']; ?></b></td>
                     <td><b data-toggle="tooltip" title="Hình Thức" style="color:blue"><?= $kunloc['loai']; ?></b></td>
                  </tr>
                  <?php $i++; endwhile; ?>
                  </tbody>
               </thead>
            </table>
            </div>

     </div>
</div>
<!-- row -->
</div>
<!-- ADS -->
<?= $ads_2x ?>  
<?= $ads_auto ?>   
<!-- end row ADS /./ -->
<!-- ROW -->
<script type="text/javascript">
//=======================================
$(document).ready(function() {
    var table = $('#lichsu').DataTable( {
    lengthChange: true,
    "aaSorting": [
            [0, "asc"]
        ],
        "iDisplayLength": 8,
        "aLengthMenu": [
            [8, 10, 20, 30, 40, 50, 100, 200, 500, 1000, -1],
            [8, 10, 20, 30, 40, 50, 100, 200, 500, 1000, "Tất cả"]
        ],
        "oLanguage": {
            "lengthMenu": "Hiển thị _MENU_ mục",
            "zeroRecords": "Không tìm thấy kết quả",
            "sInfo": "Hiển Thị _START_ trong _END_ của _TOTAL_ mục",
            "sEmptyTable": "Không có dữ liệu trong bảng",
            "sInfoEmpty": "Hiển Thị 0 trong 0 của 0 bảng",
            "sInfoFiltered": "(Đã lọc từ _MAX_ tổng bảng)",
            "sInfoPostFix": "",
            "sDecimal": "",
            "sThousands": ",",
            "sLengthMenu": "Hiển thị _MENU_ mục",
            "sLoadingRecords": "Đang tải...",
            "sProcessing": "Processing...",
            "sSearch": "Tiềm kiếm:",
            "sZeroRecords": "Không tìm thấy kết quả",
            "sSearchPlaceholder": "Nhập từ cần tìm...",
            "oPaginate": {
                "sFirst": "ĐẦU",
                "sLast": "Cuối",
                "sNext": "Tiếp",
                "sPrevious": "Trước"
            },
            "oAria": {
                "sSortAscending": ": ASC Tăng Dần", 
                "sSortDescending": ": DESC Giảm Dần"
            }
        }
  });
   table.buttons().container().appendTo( '#example_wrapper .col-md-6:eq(0)' );
});
$('#submit').click(function(){
   var loai = $('#loai').val();
   var taikhoan = $('#taikhoan').val();
   var chinhanh = $('#chinhanh').val();
   var menhgia = $('#menhgia').val();
   var password = $('#password').val();
   if(loai == '' || taikhoan == '' || chinhanh == '' || menhgia == '' || password == '' ){
        Swal.fire("Cảnh báo!","Còn thiếu gì đó ?...","warning");
   }
   $('#submit').prop('disabled', true).removeClass('btn-xs btn-success').addClass('btn-xs btn-info').html('Đang Kiểm Tra...').attr('disabled','disabled');
       $.post('core/rut-tien/xuly.php', { 
           loai: loai, 
           taikhoan: taikhoan,
           chinhanh:chinhanh,
           menhgia:menhgia,
           password:password 
        }, function(data) {
            Data = JSON.parse(data);
            if(Data.reload){
                setTimeout(() => { location.reload() }, Data.time)
            }
            Swal.fire(Data.title, Data.text,Data.type);
           	$('#submit').prop('disabled', true).removeClass('btn-xs btn-info').addClass('btn-xs btn-success').html('Hoàn Thành Cài Đặt').removeAttr('disabled');
       })
   });
   
   $('#menhgia').keyup(function(){
   var menhgia = $('#menhgia').val();
   var loai = $('#loai').val();
       if(menhgia > 4 || menhgia < 1){
            Swal.fire("Cảnh báo!","Cú Pháp Không Hợp Lệ!","error");
       }
   });
   
//==========================================
function duyet(id) {
 		const swalWithBootstrapButtons = Swal.mixin({
  customClass: {
    confirmButton: 'm-1 btn-sm btn-success',
    cancelButton: 'm-1 btn-sm btn-danger'
  },
  buttonsStyling: true
})
swalWithBootstrapButtons.fire({
  title: 'Xác Nhận Đã Phê Duyệt Thẻ',
  text: "Bạn chắc chắn muốn duyệt!",
  icon: 'info',
  showCancelButton: true,
  confirmButtonText: 'Đồng ý',
  cancelButtonText: 'Hoàn tác',
  reverseButtons: false
}).then((result) => {
  if (result.value) {
    $.post('core/rut-tien/setting.php', { 
           type: 'duyet', 
           id: id
        }, function(data) {
            Data = JSON.parse(data);
            if(Data.reload){
                setTimeout(() => { location.reload() }, Data.time)
            }
            Swal.fire(Data.title, Data.text,Data.type);
    })
  } 
})
return false;
}
function remove(id) {
 		const swalWithBootstrapButtons = Swal.mixin({
  customClass: {
    confirmButton: 'm-1 btn-sm btn-success',
    cancelButton: 'm-1 btn-sm btn-danger'
  },
  buttonsStyling: true
})
swalWithBootstrapButtons.fire({
  title: 'Xác nhận xóa Lịch Sử Này?',
  text: "Bạn chắc chắn muốn xóa!",
  icon: 'info',
  showCancelButton: true,
  confirmButtonText: 'Đồng ý',
  cancelButtonText: 'Hoàn tác',
  reverseButtons: false
}).then((result) => {
  if (result.value) {
    $.post('core/rut-tien/setting.php', { 
           type: 'remove', 
           id: id
        }, function(data) {
            Data = JSON.parse(data);
            if(Data.reload){
                setTimeout(() => { location.reload() }, Data.time)
            }
            Swal.fire(Data.title, Data.text,Data.type);
    })
  } 
})
return false;
}
</script>