<?php
    session_start();
    require_once("../../config.php");
    if(isset($_REQUEST['type']) && $_POST['id']){
        $Case_ = $_REQUEST['type'];
        switch($Case_){
            case 'duyet':
                $i = intval($_POST['id']);
                if($username != $admin){
                    $JSON = array(
                        "title" => "Bạn không có quyền",
                        "text" => "Không thể duyệt id này",
                        "type" => "error"
                    );
                    die(json_encode($JSON, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
                }
                $kiem_tra = mysqli_query($kunloc,"SELECT * FROM blog WHERE id = '$i' ");
                if(mysqli_num_rows($kiem_tra) == 1){
                    $Get_Info = mysqli_fetch_object($kiem_tra);
                    mysqli_query($kunloc,"UPDATE blog SET trangthai = '1' WHERE id = '".$Get_Info->id."' ");
                    $JSON = array(
                        "title" => "Đã duyệt thành công",
                        "text" => "Chờ reload...",
                        "type" => "success",
                        "reload" => "true",
                        "time" => $time_swal
                    );
                    die(json_encode($JSON, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
                }else{
                    $JSON = array(
                        "title" => "Giao dịch không tồn tại",
                        "text" => "Xin thử lại",
                        "type" => "error",
                        "reload" => "true",
                        "time" => $time_swal
                    );
                    die(json_encode($JSON, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
                }
            break;
            case 'an':
                $i = intval($_POST['id']);
                if($username != $admin){
                    $JSON = array(
                        "title" => "Bạn không có quyền",
                        "text" => "Không thể duyệt id này",
                        "type" => "error"
                    );
                    die(json_encode($JSON, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
                }
                $kiem_tra = mysqli_query($kunloc,"SELECT * FROM blog WHERE id = '$i' ");
                if(mysqli_num_rows($kiem_tra) == 1){
                    $Get_Info = mysqli_fetch_object($kiem_tra);
                    mysqli_query($kunloc,"UPDATE blog SET trangthai = '0' WHERE id = '".$Get_Info->id."' ");
                    $JSON = array(
                        "title" => "Đã ẩn thành công",
                        "text" => "Chờ reload...",
                        "type" => "success",
                        "reload" => "true",
                        "time" => $time_swal
                    );
                    die(json_encode($JSON, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
                }else{
                    $JSON = array(
                        "title" => "Giao dịch không tồn tại",
                        "text" => "Xin thử lại",
                        "type" => "error",
                        "reload" => "true",
                        "time" => $time_swal
                    );
                    die(json_encode($JSON, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
                }
            break;
            #----------------------------------------------------------------
            case 'remove':
                $i = intval($_POST['id']);
                if($username != $admin){
                    $JSON = array(
                        "title" => "Bạn không có quyền",
                        "text" => "Không thể duyệt id này",
                        "type" => "error"
                    );
                    die(json_encode($JSON, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
                }
                mysqli_query($kunloc,"DELETE FROM blog WHERE id = '$i'");
                mysqli_query($kunloc,"DELETE FROM lich_su_mua_code WHERE id = '$i'");
                $JSON = array(
                    "title" => "Đã xóa thành công",
                    "text" => "Chờ reload...",
                    "type" => "success",
                    "reload" => "true",
                    "time" => $time_swal
                );
                die(json_encode($JSON, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
            break;
        }
    }else{
        $JSON = array(
            "title" => "Bạn không có quyền",
            "text" => "Không thể duyệt id này",
            "type" => "error"
        );
        die(json_encode($JSON, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    }
?>