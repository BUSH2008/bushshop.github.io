
<div id="edit" class="modal fade show">
           <div class="modal-dialog modal-lg">
              <div class="modal-content" style="visibility: visible; animation-duration: 0.3s; animation-name: fadeInDown">
                 <div class="modal-header">
                    <h5 class="modal-title">Chỉnh sửa bài viết</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
                 </div>
                  <form action="javascript:voild();" method="post">
                      <div class="modal-body" id="data">
                          
                      </div>
                  </form>
                <!-- /./ -->
                  
                 </div>
               <!-- /./ -->
      </div>
</div>
<script type="text/javascript">
function edit(id) {
    $.post('core/view-source/index.php', { code: id } , function(data){
        $('#edit').modal()
        $('#data').html(data);
    })   
}
</script>
<!-- ADS -->
<?= $ads_2x ?>
<?= $ads_auto ?>
<!-- /./ -->
<div class="row">
<!-- bounceIn -->
<div class="col-lg-12 features-box">
    <div class="card">
         <div class="card-header"> <h class="card-title">Danh Sách Bài Viết Đã Tạo</h></div>
         <div class="card-body">
         <div class="table-responsive">
         <table id="danh-sach" class="table table-bordered nowrap scroll-horizontal-vertical">
               <thead>
                  <tr>
                     <th>Thumbnail</th>
                     <th>Tùy Chọn</th>
                     <th>Trạng thái</th>
                     <th>GIÁ SOURCE</th>
                     <th>Thống kê bài viết</th>
                     <th>NGƯỜI TẠO</th>

                  </tr>
                <tbody>
                <?php
                     if($username == $admin){
                         $SQL = mysqli_query($kunloc,"SELECT * FROM blog ORDER by id DESC");
                     }else{
                         $SQL = mysqli_query($kunloc,"SELECT * FROM blog WHERE username = '$username' ORDER by id DESC");
                     }
                     while ($kunloc = mysqli_fetch_assoc($SQL)): ?>
                  <tr>
                      <td>
                        <div class="media">
                            <div class="avatar">
                                <img class="align-self-start" src="<?= $kunloc['image']; ?>" href="<?= $kunloc['image']; ?>" data-fancybox="" style="margin-left:-10px;width:250px;height:auto" alt="user avatar">
                            </div>
                        </div>
					           </td>
                     <td>
                         <?php if($username == $admin){ ?>
                         <span href="#" onclick="duyet(<?= $kunloc['id']; ?>)" class="btn-sm btn-success" data-toggle="tooltip" title="Duyệt">Duyệt</span>
                         <?php if($kunloc['trangthai'] == 1){ ?>
                         <span href="#" onclick="an(<?= $kunloc['id']; ?>)" class="btn-sm btn-warning" data-toggle="tooltip" title="Ẩn">Ẩn Bài</span>
                         <?php } ?>
                         <?php } ?>
                         <p class="mt-2"><span href="#" onclick="remove(<?= $kunloc['id']; ?>)" class="btn-sm btn-danger" data-toggle="tooltip" title="Nhấp vào để xóa">Gỡ bài viết</span></p>
                         <p class="mt-2"><span href="#" onclick="edit(<?= $kunloc['code']; ?>)" class="btn-sm btn-info" data-toggle="tooltip" title="Nhấp vào để sửa">Chỉnh sửa bài viết</span></p>
                     
                     </td>
                     <td>
                      Mã code:<b data-toggle="tooltip" title="Mã CODE" style="color:blue"><code><?= $kunloc['code']; ?></code></b><br>
                      Ngày đăng: <b data-toggle="tooltip" title="Ngày tạo" style="color:black"><?= $kunloc['date']; ?></b><br>
                      Tiêu đề: <b data-toggle="tooltip" title="Tiều đề" style="color:blue"><?= $kunloc['title']; ?></b><br>
                      <b data-toggle="tooltip" title="Trạng thái" style="color:black">
                      <?php if($kunloc['trangthai'] == 1){
                        echo 'Bài viết đang: công khai';
                      }else{
                        echo 'Bài viết đang: Riêng tư';
                      }
                      ?>
                      </b>
                     </td>
                     <td>
                      <b data-toggle="tooltip" title="Giá source" style="color:green">
                      <?php if($kunloc['gia'] != 0){
                        echo number_format($kunloc['gia']);
                      }else{
                        echo 'Miễn phí';
                      }
                      ?>
                      </b> VND</td>
                     <td>
                      <ul class="list-inline mb-2">
                        <li class="list-inline-item"><b class="text-warning"><?= $kunloc['view']; ?></b> <i class="icon-eye icons"></i>Lượt xem</li><br>
                        <li class="list-inline-item"><b class="text-warning"><?= $kunloc['pay']; ?> </b> <i class="fa fa-money"></i> Lượt Mua</li>
                      </ul>
                     </td>
                     <td><b data-toggle="tooltip" title="Người tạo" style="color:green"><?= $kunloc['username']; ?></b></td>
                     
                  
                  </tr>
                  <?php $i++; endwhile; ?>
                  </tbody>
               </thead>
            </table>
            </div>

     </div>
</div>


</div>
<!-- ADS -->
<?= $ads_2x ?>  
<?= $ads_auto ?>   
<!-- end row ADS /./ -->
<script type="text/javascript">
$(document).ready(function() {
    var table = $('#danh-sach').DataTable( {
    lengthChange: true,
    "aaSorting": [
            [0, "desc"]
        ],
        "iDisplayLength": 5,
        "aLengthMenu": [
            [5, 10, 20, 30, 40, 50, 100, 200, 500, 1000, -1],
            [5, 10, 20, 30, 40, 50, 100, 200, 500, 1000, "Tất cả"]
        ],
        "oLanguage": {
            "lengthMenu": "Hiển thị _MENU_ mục",
            "zeroRecords": "Không tìm thấy kết quả",
            "sInfo": "Hiển Thị _START_ trong _END_ của _TOTAL_ mục",
            "sEmptyTable": "Không có dữ liệu trong bảng",
            "sInfoEmpty": "Hiển Thị 0 trong 0 của 0 bảng",
            "sInfoFiltered": "(Đã lọc từ _MAX_ tổng bảng)",
            "sInfoPostFix": "",
            "sDecimal": "",
            "sThousands": ",",
            "sLengthMenu": "Hiển thị _MENU_ mục",
            "sLoadingRecords": "Đang tải...",
            "sProcessing": "Processing...",
            "sSearch": "Tiềm kiếm:",
            "sZeroRecords": "Không tìm thấy kết quả",
            "sSearchPlaceholder": "Nhập từ cần tìm...",
            "oPaginate": {
                "sFirst": "ĐẦU",
                "sLast": "Cuối",
                "sNext": "Tiếp",
                "sPrevious": "Trước"
            },
            "oAria": {
                "sSortAscending": ": ASC Tăng Dần", 
                "sSortDescending": ": DESC Giảm Dần"
            }
        }
  });
   table.buttons().container().appendTo( '#example_wrapper .col-md-6:eq(0)' );
})

function duyet(id) {
 		const swalWithBootstrapButtons = Swal.mixin({
  customClass: {
    confirmButton: 'm-1 btn-sm btn-success',
    cancelButton: 'm-1 btn-sm btn-danger'
  },
  buttonsStyling: true
})
swalWithBootstrapButtons.fire({
  title: 'Xác nhận bài viết này',
  text: "Bạn chắc chắn muốn duyệt!",
  icon: 'info',
  showCancelButton: true,
  confirmButtonText: 'Đồng ý',
  cancelButtonText: 'Hoàn tác',
  reverseButtons: false
}).then((result) => {
  if (result.value) {
    $.post('core/them-source/setting.php', { 
           type: 'duyet', 
           id: id
        }, function(data) {
            Data = JSON.parse(data);
            if(Data.reload){
                setTimeout(() => { location.reload() }, Data.time)
            }
            Swal.fire(Data.title, Data.text,Data.type)
            return false;
    })
  } 
})
return false;
}
function an(id) {
 		const swalWithBootstrapButtons = Swal.mixin({
  customClass: {
    confirmButton: 'm-1 btn-sm btn-success',
    cancelButton: 'm-1 btn-sm btn-danger'
  },
  buttonsStyling: true
})
swalWithBootstrapButtons.fire({
  title: 'Xác nhận bài viết này',
  text: "Bạn chắc chắn muốn ẩn!",
  icon: 'info',
  showCancelButton: true,
  confirmButtonText: 'Đồng ý',
  cancelButtonText: 'Hoàn tác',
  reverseButtons: false
}).then((result) => {
  if (result.value) {
    $.post('core/them-source/setting.php', { 
           type: 'an', 
           id: id
        }, function(data) {
            Data = JSON.parse(data);
            if(Data.reload){
                setTimeout(() => { location.reload() }, Data.time)
            }
            Swal.fire(Data.title, Data.text,Data.type)
            return false;
    })
  } 
})
return false;
}

function remove(id) {
 		const swalWithBootstrapButtons = Swal.mixin({
  customClass: {
    confirmButton: 'm-1 btn-sm btn-success',
    cancelButton: 'm-1 btn-sm btn-danger'
  },
  buttonsStyling: true
})
swalWithBootstrapButtons.fire({
  title: 'Xác nhận xóa bài viết này?',
  text: "Bạn chắc chắn muốn xóa!",
  icon: 'info',
  showCancelButton: true,
  confirmButtonText: 'Đồng ý',
  cancelButtonText: 'Hoàn tác',
  reverseButtons: false
}).then((result) => {
  if (result.value) {
    $.post('core/them-source/setting.php', { 
           type: 'remove', 
           id: id
        }, function(data) {
            Data = JSON.parse(data);
            if(Data.reload){
                setTimeout(() => { location.reload() }, Data.time)
            }
            Swal.fire(Data.title, Data.text,Data.type)
            return false;
    })
  } 
})
return false;
}
</script>