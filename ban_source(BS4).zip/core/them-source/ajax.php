<?php
	session_start();
    require_once("../../config.php");
	if(empty($_POST['title']) || empty($_POST['image']) || empty($_POST['demo']) || empty($_POST['download']) || empty($_POST['html']) || empty($_POST['code'])){
        $JSON = array(
            "title" => "Yêu cầu thông tin",
            "text" => "Bạn chưa điền đầy đủ thông tin",
            "type" => "info",
        );
        die(json_encode($JSON, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    }
    $code = intval($_POST['code']);
    $download_source = mysqli_real_escape_string($kunloc,$_POST['download']);
    $title_source = mysqli_real_escape_string($kunloc,$_POST['title']);
    $image_source = mysqli_real_escape_string($kunloc,$_POST['image']);
    $link_source = mysqli_real_escape_string($kunloc,$_POST['demo']);
    $html_source = mysqli_real_escape_string($kunloc,$_POST['html']);
    $gia_source = str_replace('.', '', $_POST['gia']);
    if(strlen($title_source) < 10 || strlen($title_source) > 1000){
		$JSON = array(
            "title" => "Tiêu đề không hợp lệ",
			"text" => "Tối thiểu 6 > 1000 kí tự",
			"type" => "error",
        );
        die(json_encode($JSON, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    }
    if($gia_source < 0 || $gia_source > 15000000){
		$JSON = array(
            "title" => "Giá bán không hợp lệ",
			"text" => "Vui lòng thử lại từ 10.000 > 1.500.000 VND",
			"type" => "error",
        );
        die(json_encode($JSON, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    }
    if(image($image_source) == true){
        $img = $image_source;
    }else{
        $img = 'https://theme-vision.com/wp-content/uploads/2019/02/503-unavailable-error-wpk.jpg';
    }
    if(check_id($code)){
        $JSON = array(
            "title" => "Bài viết này đã tồn tại ",
			"text" => "Vui lòng thử lại!!!!",
			"type" => "error",
        );
        die(json_encode($JSON, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    }
    if(mysqli_num_rows(mysqli_query($kunloc,"SELECT * FROM blog WHERE code = '$code'"))){
        mysqli_query($kunloc,"UPDATE blog SET title='$title_source',html='$html_source',gia='$gia_source',image='$img',link='$link_source',download='$download_source' WHERE code = '$code'");
        $JSON = array(
            "title" => "Đã cập nhật bài viết",
			"text" => "Chờ hệ thống xử lý",
            "type" => "success",
            "reload" => "$domain/quan-li-source",
            "time" => $time_swal
        );
        die(json_encode($JSON, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));

    }else{
        mysqli_query($kunloc,"INSERT INTO blog(code,title,html,date,gia,username,trangthai,image,link,view,pay,download) VALUES ('$code','$title_source','$html_source','$today','$gia_source','$username','0','$img','$link_source','0','0','$download_source')");
        $JSON = array(
            "title" => "Tạo bài viết thành công",
			"text" => "Đang xử lý bài viết...",
            "type" => "success",
            "reload" => "$domain/them-source",
            "time" => $time_swal
        );
        die(json_encode($JSON, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    }
    if(create_blog($code,$title_source,$html_source,$gia_source,$username,$img,$link_source,$download_source)){
        $JSON = array(
            "title" => "Tạo Bài Viết Thành Công",
			"text" => "Chờ xử hệ thống xử lý",
            "type" => "success",
            "reload" => "$domain/them-source",
            "time" => $time_swal
        );
        die(json_encode($JSON, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    }else{
        $JSON = array(
            "title" => "Thất bại khi tạo bài viết",
			"text" => "Chờ xử hệ thống xử lý",
            "type" => "error",
            #"reload" => "$domain/them-source",
            #"time" => $time_swal
        );
        die(json_encode($JSON, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    }

function check_id($code){
$CHECK_ID = mysqli_num_rows(mysqli_query($kunloc,"SELECT * FROM blog WHERE $code = '$code'"));
if($CHECK_ID >= 1) return true;
else return false;
}
function create_blog($code,$title_source,$html_source,$gia_source,$username,$img,$link_source,$download_source){
    $create = mysqli_query($kunloc,"INSERT INTO blog(code,title,html,date,gia,username,trangthai,image,link,view,pay,download) VALUES ('$code','$title_source','$html_source','$today','$gia_source','$username','0','$img','$link_source','0','0','$download_source')");
    if($create) return true;
    else return false;
}
function image($image_source){
    $curl = curl_init($image_source);
    curl_setopt($curl, CURLOPT_NOBODY, true);
    $result = curl_exec($curl);
    if($result !== false){
       $statusCode = curl_getinfo($curl, CURLINFO_HTTP_CODE); 
       if ($statusCode != 404){
         return true;
       }else{
         return false;
       }
    }else{
        return false;  
    }
}
?>