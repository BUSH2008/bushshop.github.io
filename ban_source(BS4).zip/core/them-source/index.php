<div class="row">
        <div class="col-lg-12">
          <div class="card">
          <div class="card-header"><h class="card-title">THÊM SOURCE WEBISTE</h></div>
            <div class="card-body p-2">
             <form method="POST">
               <input id="code" type="number" class="d-none" value="<?= time() ?>"/>
                 <div class="form-group">
                    <label class="font-weight-bold">TIÊU ĐỀ BÀI VIẾT (<h style="color:red">CHỦ ĐỀ BÀI VIẾT</h>)</label>
                    <input id="title" type="text" class="form-control form-control-sm" placeholder="Điền tiêu đề bài viết" required>
                  </div>
              <!-- /./ -->
              <div class="irow row">
                  <div class="col-sm-6">
                    <div class="form-group">
                        <label class="font-weight-bold">URL LIVE(<b style="color:red">DEMO URL</b>)</label>
                        <input id="demo" type="text" class="form-control form-control-sm" value="<?= $SQL->link ?>" placeholder="ex: https://domain.com" required>
                    </div>
                    </div>
                    <!-- /./ -->
                    <div class="col-sm-6">
                    <div class="form-group">
                      <label class="font-weight-bold">URL DOWNLOAD(<b style="color:red">DOWNLOAD URL</b>)</label>
                      <input id="download" type="text" class="form-control form-control-sm" value="<?= $SQL->download ?>" placeholder="ex: https://download.zip" required>
                    </div>
                    </div>
            </div>
            <!-- /./ -->
            <div class="irow row">
               <div class="col-sm-6">
                 <div class="form-group">
                    <label class="font-weight-bold">THÊM LINK HÌNH ẢNH DEMO (<b style="color:red">IMG,PNG</b>)</label>
                    <input id="image" type="text" class="form-control form-control-sm" placeholder="ex: https://www.upsieutoc.com/images/2020/10/03/120728836_358312938688355_6932053722983812094_n.jpg" required>
                  </div>
              </div>
               <!-- /./ -->
                <div class="col-sm-6">
                   <div class="form-group">
                    <label class="font-weight-bold">CHỌN CHẾ ĐỘ SOURCE:</label>
                      <select class="form-control form-control-sm" id="type">
                        <option value="1">MIỄN PHÍ (SHARE CODE)</option>
                        <option value="2">ĐĂNG BÁN (SELL CODE)</option>
                      </select>
                  </div>
                  <div class="form-group" style="display:none;" id="form-gia">
                    <label class="font-weight-bold">GIÁ SOURCE (<b style="color:red">Min 10.000 - Max: 1.500.000 VND</b>)</label>
                    <input id="gia" type="number" class="form-control form-control-sm" placeholder="10.000 VND - 1.500.000 VND" required>
                  </div>
             </div>
          <!-- /./ -->
             </div>
                <div class="form-group">
                  <label class="font-weight-bold">NỘI DUNG BÀI VIẾT:</label>
                  <textarea id="html" type="text" class="form-control form-control-sm ckeditor"></textarea>
                </div>
                <div class="form-group">
                  <button type="submit" id="submit" class="btn-sm btn btn-outline-dark">LƯU BÀI VIẾT CỦA BẠN</button>
                </div>
              </form>
             
            </div>
    </div>
</div>

</div>
<!-- ADS -->
<?= $ads_2x ?>  
<?= $ads_auto ?>   
<!-- end row ADS /./ -->
<script src="/assets/editor/ckeditor.js"></script>
<!--link href="/assets/summernote@0.8.18/summernote-lite.css" rel="stylesheet">
<script src="/assets/summernote@0.8.18/summernote-lite.js"></script-->
<script type="text/javascript">
/*$('#html').summernote({
        placeholder: 'Điền nội dung bài viết của bạn',
        tabsize: 2,
        height: 200,
        focus: false,
        airMode: false,
        fontNames: ['Roboto', 'Calibri', 'Times New Roman', 'Arial'],
        fontNamesIgnoreCheck: ['Roboto', 'Calibri'],
        dialogsInBody: false,
        dialogsFade: false,
        disableDragAndDrop: false,

        toolbar: [
          ['style', ['bold', 'italic', 'underline', 'clear']],
          ['para', ['style', 'ul', 'ol', 'paragraph']],
          ['fontsize', ['fontsize']],
          ['font', ['strikethrough', 'superscript', 'subscript']],
          ['height', ['height']],
          ['misc', ['undo', 'redo', 'print', 'help', 'fullscreen']],
          ['table', ['table']],
          ['insert', ['link', 'picture', 'video']],
          ['view', ['codeview']]
        ],
    popover: {
      air: [
        ['color', ['color']],
        ['font', ['bold', 'underline', 'clear']]
      ]
    },
    print: {
      'stylesheetUrl': 'url_of_stylesheet_for_printing'
    }
});*/
setInterval(() => {
  var editor = CKEDITOR.replace('html');
  checkout()
}, 1e3);
function checkout(){
      var type = document.getElementById('type').value;
      if(type == 1){
        $('#form-gia').hide()
      }
      if(type == 2){
        $('#form-gia').show()
      }
}
$('#submit').click(function(){
   var code = $('#code').val();
   var title = $('#title').val();
   var image = $('#image').val();
   var demo = $('#demo').val();
   var download = $('#download').val();
   var html = CKEDITOR.instances.html.getData();
   var type = $('#type').val();
   var gia = $('#gia').val();
   if(type == 1){
      var vnd = 0;
   }else if(type == 2){
      var vnd = gia;
   }
   if(code == '' || title == '' || type == '' || html == '' || demo == '' || download == '' || image == ''){
        Swal.fire("Chưa điền đầy đủ","Chưa điền đầy đủ bài viết","error");
        return false;
   }
   $('#submit').prop('disabled', true).html('Đang Kiểm Tra...');
       $.post('core/them-source/ajax.php', { 
          code:code,
          demo:demo,
          download:download,
          image:image,
          title: title,
          html: html,
          gia: vnd
        }, function(data) {
            Data = JSON.parse(data);
            if(Data.reload){
                setTimeout(() => { location.reload() }, Data.time)
            }
            $('#submit').prop('disabled', false).html('Hoàn Thành Cài Đặt');
            Swal.fire(Data.title, Data.text,Data.type);
            return false;
           	
       })
})
</script>