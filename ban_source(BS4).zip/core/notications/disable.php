<?php
include ("../../config.php");
if($trangthai != 'disabled'){
 header("Location: $domain/Home");
 die();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no"/>
  <meta name="description" content=""/>
  <meta name="author" content=""/>
  <title>Vô Hiệu Hóa</title>
  <!--favicon-->
  <link rel="shortcut icon" href="https://img.icons8.com/cotton/64/000000/like--v3.png">
  <!-- simplebar CSS-->
  <link href="/assets/plugins/simplebar/css/simplebar.css" rel="stylesheet"/>
  <!-- Bootstrap core CSS-->
  <link href="/assets/css/bootstrap.min.css" rel="stylesheet"/>
  <!-- animate CSS-->
  <link href="/assets/css/animate.css" rel="stylesheet" type="text/css"/>
  <!-- Icons CSS-->
  <link href="/assets/css/icons.css" rel="stylesheet" type="text/css"/>
  <!-- Sidebar CSS-->
  <link href="/assets/css/sidebar-menu.css" rel="stylesheet"/>
  <!-- Custom Style-->
  <link href="/assets/css/app-style.css" rel="stylesheet"/>
 <!-- Button 2 -->
 <link href="/assets/css/button.css" rel="stylesheet"> 
</head>
<body class="gradient-steelgray">
<!-- Start wrapper-->
 <div id="wrapper">
    <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="text-center error-pages">
                        <h1 class="error-sub text-white"></h1>
                        <h2 class="error-title-title text-white">Vô Hiệu Hóa</h2>
                        <hr style="width:45%">
                        <b style="font-size:14px" class="error-title-title text-white">Xin chào, <h style="color:orange"><?= $hoten ?></h><br>Chúng tôi đã áp dụng các hình phạt sau đối với tài khoản của bạn được liệt kê ở dưới</b><BR>
                        <hr style="width:35%">
                       <b style="font-size:14px" class="error-title-title text-white">Bạn đã vị phạm 1 trong số trường hợp sau: </b>
                        <p class="m-3 error-message text-white">1. Số dư <button class="btn-xs btn-success btn-round">0</button> VND quá hạn nên sẽ banned</p>
                        <p class="m-3 error-message text-white">2. Không hoạt động trong <button class="btn-xs btn-success btn-round">48H</button></p>
                        <p class="m-3 error-message text-white">3. Bạn có một số hoạt động bất thường</p>
                        <p class="m-3 error-message text-white">4. Spam Hệ Thống (Chat,Upload quá nhiều ảnh)</p>
                        <p class="m-3 error-message text-white">5. (ĐẶC BIỆT) Hành vi : BUG Hệ Thống</p>
                        <div class="mt-4">
                          <a href="<?= $domain ?>/Logout" class="btn-sm btn-dark btn-round shadow-dark m-1">Đăng Xuất </a>
                        </div>

                        <div class="mt-4 hidden-xs">
                            <p class="text-white">Copyright © 2020 Nguyễn Thành Lộc | All rights reserved.</p>
                        </div>
                           <hr class="w-50 border-light-2">
                        <div class="mt-2 hidden-xs">
                            <a href="javascript:void()" class="btn-social btn-social-circle btn-facebook waves-effect waves-light m-1"><i class="fa fa-facebook"></i></a>
                            <a href="javascript:void()" class="btn-social btn-social-circle btn-google-plus waves-effect waves-light m-1"><i class="fa fa-google-plus"></i></a>
                            <a href="javascript:void()" class="btn-social btn-social-circle btn-behance waves-effect waves-light m-1"><i class="fa fa-behance"></i></a>
                            <a href="javascript:void()" class="btn-social btn-social-circle btn-dribbble waves-effect waves-light m-1"><i class="fa fa-dribbble"></i></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>

 </div><!--wrapper-->


  <!-- Bootstrap core JavaScript-->
  <script src="assets/js/jquery.min.js"></script>
  <script src="assets/js/popper.min.js"></script>
  <script src="assets/js/bootstrap.min.js"></script>
	
  <!-- simplebar js -->
  <script src="assets/plugins/simplebar/js/simplebar.js"></script>
  <!-- waves effect js -->
  <script src="assets/js/waves.js"></script>
  <!-- sidebar-menu js -->
  <script src="assets/js/sidebar-menu.js"></script>
  <!-- Custom scripts -->
  <script src="assets/js/app-script.js"></script>
	
</body>
</html>
