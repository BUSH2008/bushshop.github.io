<footer class="mt-5 text-muted bg-dark">
  <div class="container text-light p-4">
    <p class="float-right d-none">
      <a href="#"><button class="btn-sm btn btn-outline-info">Lên trang đầu</span></button></a>
    </p>
    <h4><?= $tieude ?></h4>
    <p>Hệ thống mua bán source,uy tín, giá rẻ chất lượng nhất việt nam</p>
    <p>Design by <a href="https://facebook.com/<?= $id_admin ?>">Kunloc Entertainment</a> .</p>
    <p>Tag: muasource,code facebook,muasource fb, sell code, code share, share code,source code fb,code viplike,code auto,code sub, code php, codeblog, wordpress,muasource,code facebook,muasource fb, sell code, code share, share code,source code fb,code viplike,code auto,code sub, code php, codeblog, wordpress,muasource,code facebook,muasource fb, sell code, code share, share code,source code fb,code viplike,code auto,code sub, code php, codeblog, wordpress,muasource,code facebook,muasource fb, sell code, code share, share code,source code fb,code viplike,code auto,code sub, code php, codeblog, wordpress,muasource,code facebook,muasource fb, sell code, code share, share code,source code fb,code viplike,code auto,code sub, code php, codeblog, wordpress</p>
  </div>
</footer>
<script type="text/javascript">
  function toarst(status, msg, title) {
        Command: toastr[status](msg, title)
        toastr.options = {
          "closeButton": false,
          "debug": false,
          "newestOnTop": true,
          "progressBar": true,
          "positionClass": "toast-top-right",
          "preventDuplicates": false,
          "onclick": null,
          "showDuration": "300",
          "hideDuration": "1000",
          "timeOut": "5000",
          "extendedTimeOut": "1000",
          "showEasing": "swing",
          "hideEasing": "linear",
          "showMethod": "fadeIn",
          "hideMethod": "fadeOut"
        }
      }
      $('.carousel').carousel({})  
</script>
<script type="text/javascript" src="https://cdn.datatables.net/1.10.22/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/1.10.22/js/dataTables.bootstrap4.min.js"></script>
</body>
</html>

